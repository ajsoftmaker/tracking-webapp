'use strict';

angular.module('trackingWebApp')
	.controller('taviewbatchreportsController', taviewbatchreportsController);

function taviewbatchreportsController($scope, $rootScope, $state, $filter, dialogs, restAPIService,$stateParams){
	$scope.type = $stateParams.type;
	$scope.reportHeading = ""
	$scope.students = [];
	$scope.studentsRecord = [];
	$scope.studentList = ["All"];
	$scope.studentBatches = [];
	$scope.studentTests = [];
	$scope.batches = [];
	$scope.courses = [];
		
	if(localStorage.getItem("logo") == "Set Default Logo") {	
		document.getElementById("headerLogo").src ="/assets/images/labjump_logo.png";
	} else {
		document.getElementById("headerLogo").src ="data:image/jpeg;base64,"+localStorage.getItem("logo");
	}
	
	localStorage.removeItem("logo");
	localStorage.removeItem("reportMode");
	
	if($stateParams.type=="complete") {
		$scope.reportHeading = "Completed Batches";
	} else {
		$scope.reportHeading = "Ongoing Batches";
	}
	
	getBatchesDetails();
	
	function getBatchesDetails() {
		var promise = restAPIService.batchesService().query();
		promise.$promise.then(
			function (response) {
				$scope.batches = [];
				var today = new Date();
				today.setHours(0);
	    		today.setMinutes(0);
	    		today.setSeconds(0);
				if($stateParams.type=="complete"){
					for(var i=0;i<response.length;i++) {
						var endDate = parseDate(response[i].endDate);
						var days = Math.round((endDate-today)/(1000*60*60*24));
						if(days<0) {
							$scope.batches.push(response[i]);
						}
					}
				} else {
					for(var i=0;i<response.length;i++) {
			    		var endDate = parseDate(response[i].endDate);
						var days = Math.round((endDate-today)/(1000*60*60*24));
			    		if(days>=0){
							var startDate = parseDate(response[i].startDate);
							days = Math.round((startDate-today)/(1000*60*60*24));
							if(days <= 0) {
								$scope.batches.push(response[i]);
							}
						}
					}
				}
				
				
				getCoursesDetails();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getCoursesDetails() {
		var promise = restAPIService.coursesService().query();
		promise.$promise.then(
			function (response) {
				$scope.courses = response;
				getAllStudents();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getAllStudents() {
		var promise1 = restAPIService.studentsService().query();
		promise1.$promise.then(
			function (response) {
				$scope.students =  response;
				getStudentBatchesDetails();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getStudentBatchesDetails() {
		var promise = restAPIService.studentBatchesService().query();
		promise.$promise.then(
			function (response) {
				$scope.studentBatches = response;
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	$scope.getCourseDetails = function(courseID) {
		for(var i=0;i<$scope.courses.length;i++) {
			if($scope.courses[i].id==courseID) {
				return $scope.courses[i].courseID+" : "+$scope.courses[i].courseName
			}
		}
	}
	
	$scope.getBatchStudent = function(batchID) {
		$scope.studentsRecord = [];
		for(var i=0;i<$scope.studentBatches.length;i++) {
			if($scope.studentBatches[i].batchID==batchID) {
				$scope.studentsRecord.push($scope.studentBatches[i]);
			}
		}
		return $scope.studentsRecord.length;
	}
	
	$scope.getStudentName = function(studentID) {
		for(var i=0;i<$scope.students.length;i++) {
			if($scope.students[i].id == studentID){
				return $scope.students[i].studentName;
			}
		}
	}
	
	$scope.getAttened = function(status) {
		if(status=="start") {
			return "Yes";
		} else {
			return "No";
		}
	}
	
	function parseDate(s) {
		  var months = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,
		                jul:6,aug:7,sep:8,oct:9,nov:10,dec:11};
		  var p = s.split('-');
		  return new Date(p[2], months[p[1].toLowerCase()], p[0]);
		}
	
}
