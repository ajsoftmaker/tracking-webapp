'use strict';

angular.module('trackingWebApp')
	.controller('taviewreportsController', taviewreportsController);

function taviewreportsController($scope, $rootScope, $state, $filter, dialogs, restAPIService,$stateParams){
	$scope.type = $stateParams.type;
	$scope.students = [];
	$scope.studentsRecord = [];
	$scope.studentList = ["All"];
	$scope.studentBatches = [];
	$scope.studentTests = [];
	$scope.batches = [];
	$scope.courses = [];
	
	if(localStorage.getItem("logo") == "Set Default Logo") {	
		document.getElementById("headerLogo").src ="/assets/images/labjump_logo.png";
	} else {
		document.getElementById("headerLogo").src ="data:image/jpeg;base64,"+localStorage.getItem("logo");
	}
	
	localStorage.removeItem("logo");
	localStorage.removeItem("reportMode");
	
	getStudentBatchesDetails();
	
	function getStudentBatchesDetails() {
		var promise = restAPIService.studentBatchesService().query();
		promise.$promise.then(
			function (response) {
				$scope.studentBatches = response;
				getBatchesDetails();
				getStudentTestsDetails();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getStudentTestsDetails() {
		var promise = restAPIService.studentTestsService().query();
		promise.$promise.then(
			function (response) {
				$scope.studentTests = response;
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getBatchesDetails() {
		var promise = restAPIService.batchesService().query();
		promise.$promise.then(
			function (response) {
				$scope.batches = response;
				getCoursesDetails();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getCoursesDetails() {
		var promise = restAPIService.coursesService().query();
		promise.$promise.then(
			function (response) {
				$scope.courses = response;
				getAllStudents();
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	function getAllStudents() {
		var promise1 = restAPIService.studentsService().query();
		promise1.$promise.then(
			function (response) {
				$scope.students =  response;
				for(var i=0;i<$scope.students.length;i++) {
					$scope.students[i].details = $scope.getBatchDetails($scope.students[i]);
				}
				$scope.studentsRecord = $scope.students;
				for(var i=0;i<$scope.students.length;i++) {
					$scope.studentList.push($scope.students[i].studentID+" : "+$scope.students[i].studentName);
				}
				/*if($rootScope.encodedLogo == "Set Default Logo") {
					document.getElementById("reportLogo").src = "/assets/images/labjump_logo.png";
				} else {
					document.getElementById("reportLogo").src ="data:image/jpeg;base64,"+$rootScope.encodedLogo;
				}*/
		    },
		    function(error){
		    	dialogs.error("Error", error.data.error, {'size': 'sm' });
		    }
		);
	}
	
	$scope.getBatchDetails = function(studentRecord){
		var detail = [];
		for(var i=0;i<$scope.studentBatches.length;i++) {
			if($scope.studentBatches[i].studentID == studentRecord.id) {
				var batchId = $scope.studentBatches[i].batchID;
				for(var j=0;j<$scope.batches.length;j++) {
					if($scope.batches[j].id == batchId) {
						var courseId = $scope.batches[j].courseID;
						for(var k=0;k<$scope.courses.length;k++) {
							if($scope.courses[k].id == courseId) {
								var temp = {};
								temp.CourseId =$scope.courses[k].courseID;
								temp.CourseName = $scope.courses[k].courseName;
								temp.startDate = $scope.batches[j].startDate;
								temp.endDate = $scope.batches[j].endDate;
								if($scope.studentBatches[i].status == "start") {
									temp.status = "Yes";
								} else {
									temp.status = "No";
								}
								detail.push(temp);
							}
						}
					}
				}
			}
		}
		return detail;
	}
	
	$scope.onChange = function(studentSelected) {
		$scope.studentsRecord =[];
		var studentId = studentSelected.split(" ");
		if(studentId[0] == "All") {
			$scope.studentsRecord = $scope.students;
		} else {
			for(var i=0;i<$scope.students.length;i++) {
				if($scope.students[i].studentID == studentId[0]) {
					$scope.studentsRecord.push($scope.students[i]);
				}
			}
		}
	}
	
	$scope.getCourseIdName = function(id) {
		for(var i=0;i<$scope.courses.length;i++) {
			if($scope.courses[i].id==id) {
				return $scope.courses[i].courseID+" : "+$scope.courses[i].courseName;
			}
		}
	}
	
	$scope.getAttenedBatchCount = function(BatchData) {
		var counter = 0;
		for(var i=0;i<BatchData.length;i++) {
			if(BatchData[i].status=="Yes") {
				counter+=1;
			}
		}
		return counter;
	}
	
	$scope.getPassTest = function(studentID) {
		var pass=0;
		for(var i=0;i<$scope.studentTests.length;i++) {
			if($scope.studentTests[i].studentID==studentID){
				if($scope.studentTests[i].results=="pass") {
					pass+=1;
				}
			}
		}
		return pass;
	}
	$scope.getfailTest = function(studentID) {
		var fail=0;
		for(var i=0;i<$scope.studentTests.length;i++) {
			if($scope.studentTests[i].studentID==studentID){
				if($scope.studentTests[i].results=="fail") {
					fail+=1;
				}
			}
		}
		return fail;
	}
	
}
