'use strict';

angular.module('trackingWebApp')
	.controller('tamanagereportsController', tamanagereportsController);

function tamanagereportsController($scope, $rootScope, $state, $filter, dialogs, restAPIService, $window, $http){
	
	$scope.allStudents = function() {
		var rootScope = $http.defaults.headers.common.Authorization;
		var logo = $rootScope.encodedLogo
		localStorage.setItem("logo",logo);
		localStorage.setItem("rootScope",rootScope);
		localStorage.setItem("reportMode",true);
		var url = $state.href('home.taviewreports',{type: 'student'});
		window.open(url,'_blank');
	}
	
	$scope.batcheReports = function(type) {
		var rootScope = $http.defaults.headers.common.Authorization;
		var logo = $rootScope.encodedLogo
		localStorage.setItem("logo",logo);
		localStorage.setItem("rootScope",rootScope);
		localStorage.setItem("reportMode",true);
		var url = $state.href('home.tabatchreports',{type: type});
		window.open(url,'_blank');
	}
	
}