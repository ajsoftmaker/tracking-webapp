'use strict';

angular.module('trackingWebApp').controller('dashboardController',
		taDashboardController);

function taDashboardController($scope, $rootScope, $state, $filter, dialogs,
		uiCalendarConfig, restAPIService, moment) {
	$scope.numberOfOngoingBatches = 0;
	$scope.numberOfOngoingStudents = 0;
	$scope.numberOfYearToDateStudents = 0;
	$scope.numberOfYearToDateBatches = 0;
	$scope.notification = true;
	$scope.acceptRequest = false;
	$scope.rejectRequest = false;
	$rootScope.fromNotification = false;
	getAllstudentTestsByResult();
	courseList();
	$scope.batches = [];
	$scope.ongoingBatches = [];
	$scope.batchRequests = [];
	$scope.yearToDateBatches = [];
	// pie chart
	$scope.resultLabel = [ "Pass", "Fail" ];
	$scope.pieChartData = [];
	$scope.courses = [];
	$scope.data = [];
	$scope.tempdata = [ [ 0 ], [ 0 ] ];
	var studentPassCount = 0;
	var studentFailCount = 0;
	$scope.studentPass = 0;
	$scope.studentFail = 0;

	function blinker() {
		$('.blink_me').fadeOut(500);
		$('.blink_me').fadeIn(500);
	}
	setInterval(blinker, 1000);

	function courseList() {
		var promise = restAPIService.coursesService().query();
		promise.$promise.then(function(response) {
			$scope.coursesData = response;
			if ($scope.coursesData.length != undefined) {
				for (var i = 0; i < $scope.coursesData.length; i++) {
					$scope.courses[i] = $scope.coursesData[i].courseID;
				}
			}
			getAllBatches();
			getAllBatchesByRequestStatus();
			getAllBatchRequests();
		}, function(error) {
			dialogs.error("Error", error.data.error, {
				'size' : 'sm'
			});
		});
		var promise = restAPIService.getPassOrFailByCoursesService().get();
		promise.$promise.then(function(response) {
			var pass = response.pass;
			pass = pass.replace(/[\[\]']+/g, '');
			var fail = response.fail;
			fail = fail.replace(/[\[\]']+/g, '');
			$scope.tempdata[0][0] = pass;
			$scope.tempdata[1][0] = fail;
			angular.forEach($scope.tempdata, function(value, key) {
				var newArray = [];
				var dummyArr = value[0].split(",");
				angular.forEach(dummyArr, function(value, key) {
					newArray.push(Number(value))
				});
				$scope.data.push(newArray);
			});
		}, function(error) {
			dialogs.error("Error", error.data.error, {
				'size' : 'sm'
			});
		});
	}

	function getAllBatches() {
		var promise1 = restAPIService.batchesService().query();
		promise1.$promise.then(function(response) {
			$scope.batches = response;
			groupBatchesByTimeline();
			for (var i = 0; i < $scope.batches.length; i++) {
				var temp = {};
				temp.title = getCourseName($scope.batches[i].courseID);
				temp.start = new Date($scope.batches[i].startDate);
				temp.end = new Date($scope.batches[i].endDate);
				temp.allDay = false;
				temp.backgroundColor = getColor($scope.batches[i].startDate,
						$scope.batches[i].endDate);
				$scope.calendarDate[0].events.push(temp);
			}

		}, function(error) {
			dialogs.error("Error", error.data.error, {'size' : 'sm'});
		});
	}

	function getCourseName(id) {
		$scope.coursesData;
		for (var i = 0; i < $scope.coursesData.length; i++) {
			if ($scope.coursesData[i].id == id) {
				return $scope.coursesData[i].courseName;
			}
		}
	}

	function getColor(startDate, endDate) {
		var today = new Date();
		today.setHours(0);
		today.setMinutes(0);
		today.setSeconds(0);
		var startDate = parseDate(startDate);
		var endDate = parseDate(endDate);
		var days = Math.round((startDate - today) / (1000 * 60 * 60 * 24));
		var enddays = Math.round((endDate - today) / (1000 * 60 * 60 * 24));
		if (enddays >= 0) {
			if (days <= 6) {
				return 'green';
			} else {
				return 'orange';
			}
		} else {
			return 'red';
		}
	}

	function groupBatchesByTimeline() {
		for (var j = 0; j < $scope.batches.length; j++) {
			var today = new Date();
			today.setHours(0);
			today.setMinutes(0);
			today.setSeconds(0);
			var currentDate = new Date();
			var currentYear = currentDate.getFullYear();
			var date = new Date();
			date.setFullYear(currentYear, 0, 1);
			date.setHours(0);
			date.setMinutes(0);
			date.setSeconds(0);
			var startDate = parseDate($scope.batches[j].startDate);
			var endDate = parseDate($scope.batches[j].endDate);
			var startDateYear = $scope.batches[j].startDate.split('-');

			// yearToDate
			if (startDateYear[2] == currentYear) {
				var yearToDate = Math.round((startDate - date) / (1000 * 60 * 60 * 24));

				if (yearToDate >= 0) {
					$scope.yearToDateBatches.push($scope.batches[j]);
					var promise = restAPIService.studentsService().query();
					promise.$promise.then(
						function(response) {
							$scope.numberOfYearToDateStudents = $scope.numberOfYearToDateStudents + response.length;
						}, function(error) {
							dialogs.error("Error",error.data.error, {'size' : 'sm'});
						}
					);
				}
			}
			// ongoing
			var endDays = Math.round((endDate - today) / (1000 * 60 * 60 * 24));
			if (endDays >= 0) {
				var days = Math.round((startDate - today) / (1000 * 60 * 60 * 24));
				if (days <= 0) {
					$scope.ongoingBatches.push($scope.batches[j]);
					var promise = restAPIService.studentsService().query();
					promise.$promise.then(
						function(response) {
							$scope.numberOfOngoingStudents = $scope.numberOfOngoingStudents + response.length;
						}, function(error) {
							dialogs.error("Error",error.data.error, {'size' : 'sm'});
						}
					);
				}
			}
		}
		if ($scope.ongoingBatches.length != undefined) {
			$scope.numberOfOngoingBatches = $scope.ongoingBatches.length;
		} else {
			$scope.numberOfOngoingBatches = 0;
		}

		if ($scope.yearToDateBatches.length != undefined) {
			$scope.numberOfYearToDateBatches = $scope.yearToDateBatches.length;
		} else {
			$scope.numberOfYearToDateBatches = 0;
		}
	}

	function parseDate(s) {
		var months = {
			jan : 0,
			feb : 1,
			mar : 2,
			apr : 3,
			may : 4,
			jun : 5,
			jul : 6,
			aug : 7,
			sep : 8,
			oct : 9,
			nov : 10,
			dec : 11
		};
		var p = s.split('-');
		return new Date(p[2], months[p[1].toLowerCase()], p[0]);
	}

	function getAllBatchesByRequestStatus() {
		var promise = restAPIService.batchRequestsByRequestStatusService("Accepted").query();
		promise.$promise.then(function(response) {
			if (response.length != undefined) {
				$scope.scheduledStudents = 0;
				for (var i = 0; i < response.length; i++) {
					$scope.scheduledStudents = $scope.scheduledStudents + response[i].numStudents;
				}
				$scope.scheduledBatches = response.length;
			} else {
				$scope.scheduledStudents = 0;
				$scope.scheduledBatches = 0;
			}
		}, function(error) {
			dialogs.error("Error", error.data.error, {'size' : 'sm'});
		});
	}

	// Student test by result
	function getAllstudentTestsByResult() {
		var promise = restAPIService.studentTestsByResultService("pass").get();
		promise.$promise.then(function(response) {
			$scope.pieChartData[0] = response.success;
		}, function(error) {
			dialogs.error("Error", error.data.error, {'size' : 'sm'});
		});

		var promise = restAPIService.studentTestsByResultService("fail").get();
		promise.$promise.then(function(response) {
			$scope.pieChartData[1] = response.success;
		}, function(error) {
			dialogs.error("Error", error.data.error, {'size' : 'sm'});
		});

	}
	// bar chart
	$scope.calendarDate = [ {
		events : [],
	} ];

	$scope.setCalDate = function(date, jsEvent, view) {
		var selectedDate = moment(date).format('YYYY-MM-DD'); // set dateFrom
		// based on user
		// click on
		// calendar
		$scope.calendarDate[0].events[0].start = selectedDate; // update
		// Calendar
		// event
		// dateFrom
		$scope.selectedDate = $filter('date')(selectedDate, 'yyyy-MM-dd');
		// update $scope.dateFrom
		console.log('$scope.uiConfig', $scope.uiConfig);
		console.log('uiCalendarConfig', uiCalendarConfig);
	};

	$scope.uiConfig = {
		calendar : {
			editable : false,
			aspectRatio : 2,
			header : {
				left : 'title',
				center : '',
				right : 'today prev,next'
			},
			dayClick : $scope.setCalDate,
			background : '#f26522',
		},
	};

	$scope.calendarTab = 1;

	$scope.selectCalTab = function(tab) { // function to set which calendar
		// tab is shown in html via ng-if
		if (tab == 1) {
			$scope.calendarTab = 1;
		} else {
			$scope.calendarTab = 2;
		}
	};

	function getAllBatchRequests() {
		var promise1 = restAPIService.batchRequestsService().query();
		promise1.$promise.then(function(response) {
			for (var i = 0; i < response.length; i++) {
				if (response[i].notification == 1 && response[i].requestStatus == "Accepted") {
					$scope.notification = false;
					$scope.acceptRequest = true;
					$rootScope.fromNotification = true;
				}
				if (response[i].notification == 1 && response[i].requestStatus == "Declined") {
					$scope.notification = false;
					$scope.rejectRequest = true;
					$rootScope.fromNotification = true;
				}
			}
			if ($scope.acceptRequest == true && $scope.rejectRequest == true) {
				$scope.requestState = "Batch Request Accepted and Rejected!";
			} else {
				if ($scope.acceptRequest == true) {
					$scope.requestState = "Batch Request Accepted!";
				} else {
					$scope.requestState = "Batch Request Rejected!";
				}
			}
		}, function(error) {
			dialogs.error("Error", error.data.error, {'size' : 'sm'});
		});
	}

	$scope.requestBatch = function() {
		$state.go('home.tamanagebatches');
	}
}
